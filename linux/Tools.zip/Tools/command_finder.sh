#!/usr/bin/env bash
COMMAND=$1

# Check if variable is empty/unset
if [ -z "$COMMAND" ]; then
    echo "command parameter is null or empty"
fi

grep -rEl $COMMAND /etc /usr/lib /usr/local /var/log /home /root /tmp /opt /usr/sbin/ /usr/bin/ 2>/dev/null
grep -rEl $COMMAND /etc /usr/lib /usr/local /var/log /home /root /tmp /opt /usr/sbin/ /usr/bin/ 2>/dev/null